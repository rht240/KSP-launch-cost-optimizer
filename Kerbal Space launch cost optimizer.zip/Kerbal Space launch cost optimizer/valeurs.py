
"""

fichier contenant les dictionnaire contenant les valeurs utiles aux calculs
"""


G=6.674210**(-11)     #On a la constante gravitationelle en N.m^^2.kg^^-2


Liste_planet=['Mercure',
              'Venus',
              'Terre',
              'Mars',
              'Jupiter',
              'Saturne',
              'Uranus',
              'Neptune',
              'Lune',
              'initialisation',
              ]

dico_masse={'Mercure':3.285*10**24,
            'Venus':4.867*10**24,
            'Terre':5.972*10**24,
            'Mars':6.39*10**23,                 #On a les masses des planètes en Kg
            'Jupiter':1.898*10**27,
            'Saturne':5.683*10**26,
            'Uranus':8.681*10**25,
            'Neptune':1.024*10**26,
            'Lune':7.63*10**22,
            'initialisation':1,
            }

dico_rayon={'Mercure':2439.7*10**3,
            'Venus':6051.8*10**3,
            'Terre':6371*10**3,
            'Mars':3389.5*10**3,
            'Jupiter':69911*103,              #On a les rayons des planètes en m
            'Saturne':58232*10**3,
            'Uranus':25362*10**3,
            'Neptune':24622*10**3,
            'Lune':1737.4*10**3,
            'initialisation':1,
            }


# ----------------------------------------------------------------------------------------------
