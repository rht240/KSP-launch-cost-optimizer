"""
Fichier contenant les fonctions de calculs

"""



def priceAG(vsat):
    """
   Fonction calculant le prix de lancement avec Ariane Groupe

    """
   
    
    Pariane=(78.8*(6.6742*10**(-11))/9**(-11))*(vsat*3.6)
    return (Pariane)

def priceSX(vsat):
    """
   Fonction calculant le prix de lancement avec spaceX

    """
    PX=((78.8*(6.6742*10**(-11))/9**(-11))*(vsat*3.6))/2
    return (PX)
    


def Vitsat(MP,RP):
    """
    Fonction calculant la vitesse de satelisation d'une fusée depuis une planéte
    """
    
    vsat=(((6.674210**(-11)*MP)/RP)**(1/2))/3.6
    return (vsat)



def Vitlib(MP,RP):
    """
    Fonction calculant la vitesse de liberation d'une fusée depuis une planéte
    
    """
    
    vlib=((((6.674210**(-11)*MP)/RP)**(1/2))*2**(1/2))/3.6
    return (vlib)



