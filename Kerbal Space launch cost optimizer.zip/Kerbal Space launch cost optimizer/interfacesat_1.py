
#--------------------------------------------------------------------------------------
import os
from utile import *
from valeurs import *


# Etat du programme


program_terminated = False



#Donnée pour calibrer l'interface------------------------------------------------------

name='initialisation'


#--------------------------------------------------------------------------------------

def start():
    """
    Fonction utiliser pour lancer le programme.

   
    """
    interface_loop()
    

def interface_loop():
    '''Boucle de l'interface.'''
    while not program_terminated:
        display_interface()
        process_input()
        
        
        
        
#--------------------------------------------------------------------------------------      
  
def display_interface():
    '''
    Fonction permettant d'afficher l'interface.


    '''
    

    init(name)
   
    screen =''
    screen+='____________________________________________________________________________________________________\n'
    screen+='\n'
    screen+='°Mercure' '                           ''-----------------------------------------------------------\n'
    screen+='°Venus  '   '             /\            ''|                   Orbit calculator :                    |\n'                 
    screen+='°Terre  '   '            /  \           ''|                         '+name+''+str(espace(32,name))+'|\n'
    screen+='°Mars   '    '           |  O |          ''-----------------------------------------------------------\n'
    screen+='°Jupiter' '           |    |          ''| Vitesse de satellisation:       |   '+str(round(vsat))+'m/s'+str(espace(16,round(vsat)))+'|\n'
    screen+='°Saturne' '           |  O |          ''-----------------------------------------------------------\n'
    screen+='°Uranus '  '           |    |          ''| Vitesse de libération:          |   '+str(round(vlib))+'m/s'+str(espace(16,round(vlib)))+'|\n'
    screen+='°Neptune' '          /      \         ''-----------------------------------------------------------\n'
    screen+='°Lune   '    '         / _    _ \        ''|  Masse à envoyer:               |  100Kg                |\n' 
    screen+='        '        '        / / \__/ \ \       ''-----------------------------------------------------------\n'
    screen+='        '        '       /_/   **   \_\      ''|  Prix avec SpaceX:              |  '+str(round(PX))+' $'+str(espace(19,round(PX)))+'|\n'
    screen+='        '         '            ****           ''-----------------------------------------------------------\n'
    screen+='        '        '           * ** **         ''|  Prix avec Arianegroup:         |   '+str(round(Pariane))+'$'+str(espace(19,round(Pariane)))+'|\n'
    screen+='        '        '          **  *   *        ''-----------------------------------------------------------\n'
    screen+='        '        '       **  *  * **   *     ''|  Appuyez "Q" pour arrêter ou "R" pour reinitialiser     |\n'
    screen+='        '        '      *  *   *  * * **     ''-----------------------------------------------------------\n'   
    screen+='____________________________________________________________________________________________________\n'
    screen+='\n'
    screen+='Saisissez le nom de la planète autour de laquelle vous souhaitez mettre votre objet en orbite en orbite:\n'
    screen+='____________________________________________________________________________________________________\n'


    print(screen)
    

 
def espace (nbr,mot):
    """
    Fonction permettant d'aligner le tableau'
    """
   
    esp= nbr-len(str(mot))
    esp=' '*esp
    return esp




#--------------------------------------------------------------------------------------



def init(name):
    """
    La fonction inti appelle les fonction de calcul et assigne les resultats des fonction a des variables pour les afficher dans l'interface'
    """
    global vsat # vitesse de satelisation
    global vlib # vitesse de liberation
    global PX   # prix de lancement avec SpaceX
    global Pariane # prix de lancement avec Ariane Groupe
   
    MP=dico_masse[name]              
    RP=dico_rayon[name]
    vsat=Vitsat(MP,RP)
    vlib=Vitlib(MP,RP)
    PX=priceSX(vsat)
    Pariane=priceAG(vsat)
    
    return (vsat,vlib,PX,Pariane)
   
    
   

#----------------------------------------------------------------------------------------
  

def process_input():
    '''Effectue des actions en fonction du caractère  saisie.
 
    '''
    
    global name

    
    key = input()
    
    if key =='Q':
        action_quit ()
   
    elif key == 'R' :
        name='initialisation'   
    else :
        name= key
    
        
   
def action_quit ():  
    """
    fonction qui permet de quitter le programme
    """
    global program_terminated
    program_terminated = True
    

#--------------------------------------------------------------------------------------

start()             # appel de la fonction start pour lancer le programme